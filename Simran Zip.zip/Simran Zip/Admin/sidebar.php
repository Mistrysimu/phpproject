<div class=" sidebar" role="navigation">
            <div class="navbar-collapse">
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
          <ul class="nav" id="side-menu">
            <li>
              <a href="dashboard.php"><i class="fa fa-home nav_icon"></i>Dashboard</a>
            </li>
            <li>
              
              <a href="add-classes.php"><i class="fa fa-cogs nav_icon"></i>Add Classes </a>
              <a href="manage-classes.php"><i class="fa fa-cogs nav_icon"></i>Manage Classes</span> </a>
              
              <!-- /nav-second-level -->
            </li>
            <li>
              
              <a href="about-us.php"><i class="fa fa-cogs nav_icon"></i>About Us </a>
              <a href="contact-us.php"><i class="fa fa-cogs nav_icon"></i>Contact Us</span> </a>
              
              <!-- /nav-second-level -->
            </li>
          
            <li>
              <a href="all-appointment.php"><i class="fa fa-check-square-o nav_icon"></i>All Appointment</a>
              <a href="new-appointment.php"><i class="fa fa-check-square-o nav_icon"></i>New Appointment</a>
              <a href="accepted-appointment.php"><i class="fa fa-check-square-o nav_icon"></i>Accepted Appointment</a>
              <a href="rejected-appointment.php"><i class="fa fa-check-square-o nav_icon"></i>Rejected Appointment</a>
              
              <!-- //nav-second-level -->
            </li>
           
        
          
             <li>
              <a href="customer-list.php" class="chart-nav"><i class="fa fa-users nav_icon"></i>Customer List</a>
            </li>
             
             
    <li>
              <a href="invoices.php" class="chart-nav"><i class="fa fa-file-text-o nav_icon"></i>Invoices</a>
            </li>
            <li>
              <a href="search-appointment.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>Search Appointment</a>
            </li>
            <li>
              <a href="search-invoices.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>Search Invoice</a>
            </li>
          

          </ul>
          <div class="clearfix"> </div>
          <!-- //sidebar-collapse -->
        </nav>
      </div>
    </div>