<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simms_Yoga</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./css/style.css">

</head>
<body>

<!--navbar-->

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
   <b> <a class="navbar-brand" href="#">Yoga Classes Managemnet System</a></b>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="about.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="services.php">Our Classes</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../Admin/index.php">Admin</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="signup.php">Sign Up</a>
        </li>

      </ul>
    </div>
  </div>
</nav>

<!--carousel-->


<header>
      <label for="slide-1" id="slide-1"></label>
      <label for="slide-2" id="slide-2"></label>
    </header>
  </div>
</div> 
<section class="w3l-call-to-action_9">
    <div class="call-w3 ">
        <div class="container">
            <div class="grids">
                    <div class="grids-content row">

                        <div class="column col-lg-4 col-md-6 color-2 ">
                            <div>
                            <h4 class=" ">Simms Yoga Classes For Healthy And Fit Body</h4>
                            <p class="para ">“True yoga is not about the shape of your body, but the shape of your life. Yoga is not to be performed; yoga is to be lived. Yoga doesn’t care about what you have been; yoga cares about the person you are becoming. Yoga is designed for a vast and profound purpose, and for it to be truly called yoga, its essence must be embodied.” — Aadil Palkhivala</p>
                            <a href="about.php" class="action-button btn mt-md-4 mt-3">Read more</a>
                        </div>
                    </div>
                        <div class="column col-lg-8 col-md-8 col-sm-7back-image  ">
                            <img src="../User/Images/1.jpg" alt="product" class="img-responsive ">
                        </div>
                        
                    </div>
                </div>
        </div>
    </div>
    
</section>


<section class="w3l-teams-15">
  
	<div class="team-single-main ">
		
		
				<div class="column2 image-text">
					<h3 class="team-head ">Come experience the secrets of relaxation</h3>
					<p class="para  text ">
          It is true that the subliminal in man is the largest part of his nature and has in it the secret of the unseeen dynamisms which explain his surface activities. But the lower vital subconscious which is all that this psycho-analysis of Freud seems to know, - and of that it knows only a few ill-lit corners, - is no more than a restricted and very inferior portion of the subliminal whole... to begin by opening up the lower subconscious, risking to raise up all that is foul or obscure in it, is to go out of one's way to invite trouble.</p>
						<a href="login.php" class="btn logo-button top-margin mt-4">Book Your Class Now</a>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="w3l-specification-6">
    <div class="specification-layout ">
        <div class="container">
            <div class=" row">
                <div class="col-lg-6  back-image">
                    <img src="../User/Images/2.jpg" alt="product" class="img-responsive ">
                </div>
                <div class="col-lg-6 about-right-faq align-self">
                    <h3 class="title-big"><a href="about.html">Your Health is Most Important</a></h3>
                    <p class="mt-3 para"> Their array of Yoga types are availble for you Like Hath Yoga , Aasanas , Advance Yoga , Bhakti Yoga , Ashtang Yoga , Patanjal gyan Yoga and many More You want to learn.</p>
                        <div class="hair-cut">
                            <div >
                    <ul class="w3l-right-book">
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Astang Yoga</a></li>
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Hath Yoga</a></li>
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Bhakti Yoga</a></li>
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Advance Yoga</a></li>
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Aasanas</a></li>
                    </ul>
                </div>
                    <div  class="image-right">
                        <ul class="w3l-right-book">
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Yoga For Hair Growth</a></li>
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Yoga For Skin Glow</a></li>
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Face Yoga</a></li>
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Eyes Yoga</a></li>
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">Meditation and Relaxation</a></li>
                        </ul>
                </div>
            </div>
        </div>
</section>


<!--Footer-->

<section class="w3l-footer-29-main">
    <div class="footer-29 py-5">
      <div class="container py-lg-4">
        <div class="row footer-top-29">
          <div class="col-lg-4 col-md-6 col-sm-8 footer-list-29 footer-1">
            <h6 class="footer-title-29">Contact Us</h6>
            <ul>
                            <li>
                <span class="fa fa-map-marker"></span> <p>B-101,Sai Pujan Residency, Jahangirpura ,Surat.</p>
              </li>
              <li><span class="fa fa-phone"></span><a href="tel:+7-800-999-800"> +9313459828</a></li>
              <li><span class="fa fa-envelope-open-o"></span><a href="mailto:parlour@mail.com" class="mail">
                  simran2312mistry@gmail.com</a></li>            </ul>
          </div>
          <div class="col-lg-4 col-md-6 col-sm-4 footer-list-29 footer-2 ">
  
            <ul>
              <h6 class="footer-title-29">Useful Links</h6>
              <li><a href="index.php">Home</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="services.php"> Our Classes</a></li>
              <li><a href="contact.php">Contact us</a></li>
            </ul>
          </div>
         
          <div class="col-lg-4 col-md-6 col-sm-7 footer-list-29 footer-4">
                        <h6 class="footer-title-29">About Us </h6>
            <p>        Yoga is a meditative process of self-discovery and liberation. It is a diverse collection of practices that aims to control the mind, recognize a detached witness consciousness, and free oneself from the cycle of birth and death. It teaches us to see ourselves clearly, to understand what is true about who we are, and to let go of anything that does not serve us. It helps us to become aware of our thoughts, feelings, and beliefs.</p>  
          </div>
        </div>
      </div>
    </div>
  </section>
    
</body>
</html>